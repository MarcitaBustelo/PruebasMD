## INDICE
[1. Crear la aplicación](#crear-la-aplicación)

[2. JarFile (exportar código)](#jarfile)

[3. Símbolo del sistema](#símbolo-del-sistema)

[4. Instalar Launch4j](#instalar-launch4j)

[5. Configuración de Launch4j](#configuración-de-launch4j)

---

> ### *Crear la aplicación*
>>Crear un código java en eclipse 
![Imagen](1.png)
---
[^Volver al Incide^](#indice)
> ### *JarFile*
>>1. Seleccione ![Imagen](3.png)      
>>2. Después seleccionamos  ![Imagen](4.png)
>>3. Después ![Imagen](5.png)
>>4. Y por ultimo, seleccionar nuestro java project
![Imagen](2.png)
---
[^Volver al Incide^](#indice)

> ### *Símbolo del sistema*
>>Comprobar que funciona el código realizado de java
![Imagen](6.png)
---
[^Volver al Incide^](#indice)
>### *Instalar Launch4j*
>>Descargamos y instalamos Launch4j, sirve para pasar de .JAR a .exe
![Imagen](7.png)![Imagen](8.png)
---
[^Volver al Incide^](#indice)

> ### *Configuración de Launch4j*
>>1. Tenemos que añadir donde queremos que se cree con el nombre y su extensión .exe
>>2. Luego donde esta el .JAR
>>3. Y si queremos añadir una imagen, y listo para ejecutar. 
![Imagen](9.png) ![Imagen](10.png)
---
[^Volver al Incide^](#indice)


